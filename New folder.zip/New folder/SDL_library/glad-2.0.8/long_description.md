Glad
----

Glad uses the official Khronos-XML specs to generate a
GL/GLES/EGL/GLX/VK/WGL Loader made for your needs.

Checkout the GitHub repository: https://github.com/Dav1dde/glad
